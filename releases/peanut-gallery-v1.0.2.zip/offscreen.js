/**
 * Peanut Gallery — Offscreen Audio Processor
 *
 * Invisible page that handles:
 * 1. Audio capture via getUserMedia (service workers can't use AudioContext)
 * 2. Downsampling to 16kHz PCM + streaming to server
 * 3. SSE stream parsing — forwards transcript/persona events to side panel
 */

console.log("[PG:off] offscreen.js LOADED v2");

let audioContext = null;
let mediaStream = null;
let processor = null;
let sendInterval = null;
let chunkBuffer = [];
let capturing = false;
let serverUrl = "";
let sessionId = "";
let sseAbortController = null;

// ── Message handler ──
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("[PG:off] message received:", message?.type, "target:", message?.target);
  if (message.target !== "offscreen") return false;

  if (message.type === "START_RECORDING") {
    console.log("[PG:off] → START_RECORDING, serverUrl:", message.serverUrl, "streamId len:", message.streamId?.length);
    startRecording(message)
      .then(() => { console.log("[PG:off] ✓ startRecording ok"); sendResponse({ ok: true }); })
      .catch((err) => { console.error("[PG:off] ✗ startRecording err:", err.message); sendResponse({ error: err.message }); });
    return true;
  }

  if (message.type === "STOP_RECORDING") {
    stopRecording();
    sendResponse({ ok: true });
    return false;
  }

  if (message.type === "QUERY_STATUS") {
    sendResponse({ capturing, serverUrl, sessionId });
    return false;
  }

  if (message.type === "PING") {
    sendResponse({ pong: true });
    return false;
  }
});
console.log("[PG:off] message listener registered");

async function startRecording(config) {
  if (capturing) {
    console.log("[PG] Already capturing, stopping first...");
    stopRecording();
  }

  // Normalize: strip trailing slash, and auto-prepend http:// if the user
  // typed "localhost:3000" instead of "http://localhost:3000". Without a
  // scheme, fetch() treats "localhost" as the scheme and errors out.
  let raw = (config.serverUrl || "").trim().replace(/\/$/, "");
  if (raw && !/^https?:\/\//i.test(raw)) raw = "http://" + raw;
  serverUrl = raw;
  console.log(`[PG] Starting capture → ${serverUrl}`);

  // Step 1: Create server session (SSE)
  const headers = { "Content-Type": "application/json" };
  if (config.apiKeys?.deepgram) headers["X-Deepgram-Key"] = config.apiKeys.deepgram;
  if (config.apiKeys?.groq) headers["X-Groq-Key"] = config.apiKeys.groq;
  if (config.apiKeys?.anthropic) headers["X-Anthropic-Key"] = config.apiKeys.anthropic;
  if (config.apiKeys?.brave) headers["X-Brave-Key"] = config.apiKeys.brave;

  sseAbortController = new AbortController();

  const res = await fetch(`${serverUrl}/api/transcribe`, {
    method: "POST",
    headers,
    body: JSON.stringify({
      url: config.youtubeUrl || "",
      mode: "browser",
      isLive: false,
    }),
    signal: sseAbortController.signal,
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: "Server error" }));
    throw new Error(err.error || `Server returned ${res.status}`);
  }

  sessionId = res.headers.get("X-Session-Id");
  if (!sessionId) throw new Error("No session ID returned from server");

  console.log(`[PG] Session created: ${sessionId}`);
  // NOTE: chrome.storage is not available in offscreen documents (only
  // chrome.runtime + DOM APIs). The side panel receives sessionId via the
  // SSE "status" event broadcast below, so persisting here was redundant.

  // Broadcast session start to side panel
  broadcast({ type: "SSE_EVENT", event: "status", data: { status: "started", sessionId } });

  // Parse SSE stream and forward events to side panel
  readSSE(res.body);

  // Step 2: Capture tab audio
  try {
    mediaStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: {
          chromeMediaSource: "tab",
          chromeMediaSourceId: config.streamId,
        },
      },
    });
  } catch (err) {
    // Chrome's "Error starting tab capture" almost always means the streamId
    // was stale (SW evicted, extension reloaded, tab navigated, or just
    // expired). Translate into something the user can act on.
    const msg = /tab capture/i.test(err.message)
      ? "Capture token expired. Click the 🥜 icon on this YouTube tab again, then Start Listening within 60 seconds."
      : err.message;
    throw new Error(msg);
  }

  if (!mediaStream.getAudioTracks().length) {
    throw new Error("No audio track in captured stream");
  }

  console.log(`[PG] Got audio: ${mediaStream.getAudioTracks()[0].label}`);

  // Audio processing pipeline
  audioContext = new AudioContext({ sampleRate: 48000 });
  const source = audioContext.createMediaStreamSource(mediaStream);
  processor = audioContext.createScriptProcessor(4096, 1, 1);

  processor.onaudioprocess = (event) => {
    const input = event.inputBuffer.getChannelData(0);
    // Pass audio through to destination so the user still hears YouTube.
    // Tab capture mutes the tab by default; this restores it.
    event.outputBuffer.getChannelData(0).set(input);
    // Also buffer a copy for upload to the server.
    if (capturing) chunkBuffer.push(new Float32Array(input));
  };

  // Single path: source → processor → destination.
  // The processor MUST connect to destination or onaudioprocess won't fire
  // (that's why connecting `source` directly to destination and leaving the
  // processor dangling silently stops capture).
  source.connect(processor);
  processor.connect(audioContext.destination);

  capturing = true;
  chunkBuffer = [];
  sendInterval = setInterval(flushAudio, 250);

  console.log("[PG] Audio capture started");
}

function stopRecording() {
  console.log("[PG] Stopping capture...");
  capturing = false;

  if (sendInterval) { clearInterval(sendInterval); sendInterval = null; }
  flushAudio();

  if (processor) { processor.disconnect(); processor = null; }
  if (audioContext) { audioContext.close().catch(() => {}); audioContext = null; }
  if (mediaStream) { mediaStream.getTracks().forEach((t) => t.stop()); mediaStream = null; }
  if (sseAbortController) { sseAbortController.abort(); sseAbortController = null; }

  // Tell server to stop
  if (serverUrl && sessionId) {
    fetch(`${serverUrl}/api/transcribe`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId }),
    }).catch(() => {});
  }

  broadcast({ type: "SSE_EVENT", event: "status", data: { status: "stopped" } });

  chunkBuffer = [];
  sessionId = "";
  console.log("[PG] Capture stopped");
}

/** Broadcast a message to all extension contexts (side panel, background, etc.) */
function broadcast(msg) {
  // chrome.runtime.sendMessage delivers to all listeners in the extension
  // (side panel, background, etc.) — no target needed
  chrome.runtime.sendMessage(msg).catch(() => {
    // No listeners yet (side panel may not be open) — that's fine
  });
}

/**
 * Parse SSE stream from server and forward each event to the side panel.
 */
async function readSSE(body) {
  if (!body) return;

  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";

      let eventType = "";
      for (const line of lines) {
        if (line.startsWith("event: ")) {
          eventType = line.slice(7).trim();
        } else if (line.startsWith("data: ") && eventType) {
          try {
            const data = JSON.parse(line.slice(6));
            broadcast({ type: "SSE_EVENT", event: eventType, data });
          } catch {
            // Malformed JSON — skip
          }
          eventType = "";
        }
      }
    }
  } catch (err) {
    if (err.name !== "AbortError") {
      console.error("[PG] SSE read error:", err);
    }
  }
}

/**
 * Flush buffered audio → downsample → PCM → base64 → server PATCH
 */
function flushAudio() {
  if (chunkBuffer.length === 0 || !serverUrl || !sessionId) return;

  const chunks = chunkBuffer;
  chunkBuffer = [];

  // Merge
  const totalLength = chunks.reduce((sum, c) => sum + c.length, 0);
  const merged = new Float32Array(totalLength);
  let offset = 0;
  for (const chunk of chunks) { merged.set(chunk, offset); offset += chunk.length; }

  // Downsample 48kHz → 16kHz
  const ratio = (audioContext?.sampleRate || 48000) / 16000;
  const downsampled = new Float32Array(Math.floor(merged.length / ratio));
  for (let i = 0; i < downsampled.length; i++) {
    downsampled[i] = merged[Math.floor(i * ratio)];
  }

  // Float32 → Int16 PCM
  const pcm = new Int16Array(downsampled.length);
  for (let i = 0; i < downsampled.length; i++) {
    const s = Math.max(-1, Math.min(1, downsampled[i]));
    pcm[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }

  // Base64
  const bytes = new Uint8Array(pcm.buffer);
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  const base64 = btoa(binary);

  if (base64.length > 0) {
    fetch(`${serverUrl}/api/transcribe`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId, action: "audio_chunk", audio: base64 }),
    }).catch(() => {});
  }
}
